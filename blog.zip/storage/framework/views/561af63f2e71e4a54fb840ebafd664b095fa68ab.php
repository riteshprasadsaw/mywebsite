<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">


        <?php if(auth()->user()->isOnGracePeriod()): ?>

            <div class="panel panel-default">
                <div class="panel-heading">Grace Period</div>

                <div class="panel-body">
                      
                   <p>
                       Your subscription will fully expire on <?php echo e(auth()->user()->subscription_end_at->format('y-m-d')); ?>

                   </p>

                   <form method="POST" action="/subscriptions">
                       <?php echo e(method_field('PATCH')); ?>

                       <?php echo e(csrf_field()); ?>


                       <div class="checkbox">
                           
                           <label>
                               <input type="checkbox" name="resume">
                               Resume My Subscription

                           </label>
                       </div>

                       <button type="submit" class="btn btn-primary">Update </button>

                   </form>
    
                </div>
            </div>

        <?php elseif(!auth()->user()->isSubscribed()): ?>


        
            <div class="panel panel-default">
                <div class="panel-heading">Create a Subscription</div>

                <div class="panel-body">
                      <checkout-form :plans="<?php echo e($plans); ?>"></checkout-form>
                   
    


                </div>
            </div>

          <?php endif; ?>

            <?php if(count(auth()->user()->isSubscribed())): ?>
            <div class="panel panel-default">
                <div class="panel-heading">Payments</div>

                    <div class="panel-body">

                        <ul class="list-group">

                            <?php $__currentLoopData = auth()->user()->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item"> 
                                <?php echo e($payment->created_at->diffForHumans()); ?>:
                                <strong>$<?php echo e($payment->inDollars()); ?></strong>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        

                    </div>

                
                </div>

                <?php endif; ?>

                <?php if(auth()->user()->isSubscribed()): ?>

                <div class="panel panel-default">
                <div class="panel-heading">Cancel Subscription</div>

                    <div class="panel-body">

                      <form method="POST" action="/subscriptions">

                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>


                        <button class="btn btn-danger">Cancel Subscription </button>
                        
                        </form>

                    </div>

                
                </div>

             <?php endif; ?>



            </div>



            </div>

           

        </div>


        



    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>