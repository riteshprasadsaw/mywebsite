<!DOCTYPE html>
<html>
<head>
	<title>Welcome Email</title>
</head>
<body>
		<h1>Welcome to seleniummadeeasy.com, <?php echo e($user->name); ?></h1>
</body>
</html>