Hi <?php echo e($name); ?>


<p> Your registration is complete</p>

<?php echo e(route('confirmation', $token)); ?>