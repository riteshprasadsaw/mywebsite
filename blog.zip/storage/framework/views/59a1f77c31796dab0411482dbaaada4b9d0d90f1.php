
<?php $__env->startComponent('mail::message'); ?>

Thanks so much for registering!

<?php $__env->startComponent('mail::button', ['url' => 'http:/beautomationexpert.com']); ?>
Subscribe
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::panel', ['url' => '']); ?>
This is new netflix for your career.
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>


