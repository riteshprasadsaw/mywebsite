@extends('layouts.app')

@section('content')

	<div class="container">
		<h1>Premium video</h1>

		@include('videos.player')
    </div>
@endsection