Hi {{$name}}

<p> Your registration is complete</p>

{{route('confirmation', $token)}}