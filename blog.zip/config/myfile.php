<?php
return [

	
	 'RE_CAP_SITE'=>'6LdeYhoUAAAAAL6Bi1vVWyfw_HwpEhTmG9-OQ5b8',
     'RE_CAP_SECRET'=>'6LdeYhoUAAAAAMcS_L15f7xfAiOb1E47CFobaJGz',
];